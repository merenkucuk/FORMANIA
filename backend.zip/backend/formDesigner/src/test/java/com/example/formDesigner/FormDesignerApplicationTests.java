package com.example.formDesigner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormDesignerApplicationTests {

	@Test
	void contextLoads() {
	}

}
